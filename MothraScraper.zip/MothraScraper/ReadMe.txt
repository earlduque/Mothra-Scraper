Publish Date: 9/6/2017
Created by: eduque

All included files are open source, the VBA code in the excel file is not locked. All source code can be found at https://github.com/earliodookie/Mothra-Scraper

Initial Setup:
Create a new PuTTY session, the session window must be named "AutoMothra" (with no quotations):
	1. In the PuTTY Configuration window, Select Behavior
	2. In the "Window title:" field, type in AutoMothra
	3. Load other settings according to the SOP
	
In order to the following files must be open:
	-Mothra Screens.xlsm
		-Open the file, enable Macros by selecting "Enable Content", and then say "Yes" to the Security Warning
	-MothraScraper.exe
		-Just open the file

In order to run the scraper:
	-Get to the Mothra landing page (open putty, bastion in, log in)
	-Go to Display Functions (D)
	-Go to Display MailID (F)
	-Type in a MailID and press enter, a valid user record should appear
	-Press Windows-M
	
This app also adds the following functionality:
	-Control+C no longer closes Mothra
	-Control+V actually pastes
	-Contral+A selects all